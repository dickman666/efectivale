<?php
// @deprecated Backward compatibility with 2.x, 3.0.x
class_alias('Cake\Mailer\Transport\SmtpTransport', 'Cake\Network\Email\SmtpTransport');
