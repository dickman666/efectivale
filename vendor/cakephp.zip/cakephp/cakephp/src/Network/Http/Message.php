<?php
// @deprecated Backwards compatibility with earler 3.x versions.
class_alias('Cake\Http\Client\Message', 'Cake\Network\Http\Message');
