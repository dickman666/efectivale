<?php
// @deprecated Backwards compatibility with earler 3.x versions.
class_alias('Cake\Http\Client\Auth\Digest', 'Cake\Network\Http\Auth\Digest');
